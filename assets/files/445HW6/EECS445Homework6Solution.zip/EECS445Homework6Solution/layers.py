# File: layers.py
# Contents: Neural Net Layers (a Fully Connected Layer in particular). A SoftMax Layer
# will also be implemented here.


import numpy as np

from activations_functions import activation_fns


class FCLayer(object):
    def __init__(self, fan_in, fan_out, optimizer, activation_fn='linear'):
        self.W = 2 * np.random.random((fan_in, fan_out)) - 1
        self.b = np.random.random((1, fan_out))

        self.activation = activation_fns[activation_fn][0]
        self.activation_derivative = activation_fns[activation_fn][1]

        self.optimizer = optimizer

        self._input = None
        self._output = None
        self.last_W_update = np.zeros(self.W.shape)
        self.last_b_update = np.zeros(self.b.shape)

    def forward(self, x):
        """
        --> Task 1 (b) <--
        Perform a forward step on the input with the Weights (W),
        biases (b) and activation function that define this FCLayer.
        :param x: input to forward step.
        :return: output of the forward step.
        """
        self._input = x
        self._output = (np.dot(x, self.W) + self.b)
        return self.activation(self._output)

    def backward(self, delta):
        """
        --> Task 1 (e) <--
        Returns delta for next layer AND updates the weights and biases.
        (Other implementations where the parameters of a network are updated
        all together using a separate update() method are possible, but to make
        things easier, we do both the backprop calc. and update in backward
        itself.) 
        
        ** Remember to use the optimizer and update parameters. Also, ensure
        the delta you return uses the current weights and biases (i.e.,
        before the update to parameters.) **
        
        ** Also, following defensive programming, set the _input and _output
        member variables to a sentinel value (like None). **
        
        :param delta: previous layer's delta (when looking backward), i.e.,
                      next layer's delta (when looking forward)
        :return: delta for next layer (when looking backward), i.e.,
                 delta for previous layer (when looking forward)
        """
        if self._input is None or self._output is None:
            raise Exception("Run forward before backward!")

        v = delta * self.activation_derivative(self._output)
        if len(v.shape) < 2: # Make the input a minibatch if it's not (following convention)
            v = np.array([v])

        # Calculating next delta BEFORE update
        next_delta = v.dot(self.W.T)

        # Optimization Steps
        # Note: While we always pass the last update, VanillaGradientDescent does not use it.

        new_W = self.optimizer.get_parameter_update(self.W, self._input.T.dot(v), self.last_W_update)
        self.last_W_update = self.W - new_W
        self.W = new_W

        new_b = self.optimizer.get_parameter_update(self.b, np.dot(np.ones((1, v.shape[0])), v), self.last_b_update)
        self.last_b_update = self.b - new_b
        self.b = new_b

        # Reset input and output to None
        self._input = None
        self._output = None

        # Pass the next delta for the previous layer (in the forward view)
        return next_delta


class SoftMaxLayer(object):
    def __init__(self):
        # Save input and output (following FCLayer)
        self._input = None
        self._output = None

    def forward(self, x):
        self._input = x

        # Using the Normalization Trick for Numerical Stability (See Piazza Post @602)
        e_x = np.exp((x.T - np.max(x, axis=1)).T)
        self._output = (e_x.T / e_x.sum(axis=1)).T

        return self._output

    def backward(self, delta):
        # Using simpler gradient formulation given that we are using SoftMax + Xent
        # (See Piazza Post @658). Note: The way XEnt was written ensures that we get the
        # correct gradients at each step. That is, in other words, we get dL_dy where L is
        # the XEnt function and y is the prediction of the neural net in the XEnt derivative
        # function, and we get dL_dx here where x is the input to SoftMax. Multiplication/Division
        # by the minibatch size is done to keep in accord with the averaging formulation used
        # in the XEnt loss and derivative functions.

        return self._output * (1 + delta * self._output.shape[0]) * (1 / self._output.shape[0])
