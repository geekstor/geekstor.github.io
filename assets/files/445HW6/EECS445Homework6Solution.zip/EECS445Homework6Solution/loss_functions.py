# File: loss_functions.py
# Contents: Functions used to get the loss of a neural network's predictions with respect to
# some target.

import numpy as np


def cross_entropy_loss(y, t):
    """
    --> Task 4 (b) <--
    Calculate the XEnt Loss given a prediction and
    a target.
    :param y: prediction of a neural net.
    :param t: target.
    :return: the XEnt loss given (y, t)
    """

    # For small probabilities, i.e., p ~ 0, taking logarithms can be unstable. So, we take the
    # logarithm of the maximum of the probability, p, and some small number, here 1e-100,
    # where np.log still returns a finite value (i.e., not -inf.) Note: The average gradient is
    # taken here instead of the sum which is sometimes done (particularly for XEnt.) This allows
    # for a comparison of gradients between two different algorithms using different minibatch
    # sizes for example. Additionally, when using large batches, the problem of interpreting
    # large compounded losses is no longer there (try removing the division by the minibatch size
    # here, in the XEnt derivative and change the SoftMax derivative appropriately as well to see
    # this effect on the MNIST loss when evaluating over the entire training and test sets.)
    # At any rate, an appropriate scaling of the learning rate is all that is needed to get
    # back the summed version.
    return -np.sum(t * np.log(np.maximum(y, np.array([1e-100] * np.ones_like(y))))) / y.shape[0]


def cross_entropy_loss_derivative(y, t):
    """
    --> Task 4 (b) <--
    Calculate the gradient of the XEnt Loss given a prediction and
    a target, with respect to the prediction.
    :param y: prediction of a neural net.
    :param t: target.
    :return: grad_y XEnt given (y, t)
    """
    # See the note in the cross_entropy_loss() function about the averaging over the minibatch.
    return -t / np.maximum(y, np.array([1e-100] * np.ones_like(y))) / y.shape[0]


def mean_squared_error_loss(y, t):
    """
    --> Task 1 (c) <--
    Calculate the Mean Squared Error Loss given a prediction and
    a target.
    :param y: prediction of a neural net.
    :param t: target.
    :return: the MSE loss given (y, t).
    """

    # Including a factor of 1/2 to make the gradients nice (See Piazza Post @568)
    return np.mean(0.5 * np.mean(np.power(y - t, 2)))


def mean_squared_error_loss_derivative(y, t):
    """
    --> Task 1 (c) <--
    Calculate the gradient of the Mean Squared Error Loss
    given a prediction and target with respect to the prediction.
    :param y: prediction of a neural net.
    :param t: target.
    :return: grad_y MSE given (y, t).
    """

    # Dividing by the size of the minibatch to get the averaged gradient.
    return (y - t) / y.shape[0]

loss_fns = {
    'XEnt': (cross_entropy_loss, cross_entropy_loss_derivative),
    'MSE': (mean_squared_error_loss, mean_squared_error_loss_derivative),
}
