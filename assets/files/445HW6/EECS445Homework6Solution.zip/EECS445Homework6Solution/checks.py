# File: checks.py
# Contents: Some simple checks to see if implementations of the base functions for the
# neural net abstractions are correct.

from loss_functions import *
from layers import FCLayer
from optim import *


def check1():
    optimizer = VanillaGradientDescent(lr=0.1)
    try:
        l1 = FCLayer(2, 3, optimizer)
        out = l1.forward(np.array([[1, 2]]))
        assert (out.shape == (1, 3))
        print("Passed Simple Test.")
    except:
        print("Failed Simple Test. Hint: Probably "
              "check your NumPy array shapes.")

    try:
        l1 = FCLayer(2, 3, optimizer)
        l2 = FCLayer(3, 1, optimizer)
        out = l2.forward(l1.forward(np.array([[1, 2]])))
        print("Passed MultiLayer Test.")
    except:
        print("Failed MultiLayer Test. Hint: Multiple "
              "layers are causing problems.")

    try:
        l1 = FCLayer(2, 1, optimizer)
        out = l1.forward(np.array([[1, 2], [3, 4]]))
        assert (out.shape == (2, 1))
        print("Passed Batch Test.")
    except:
        print("Failed Batch Test. Hint: Batches of inputs "
              "are causing problems.")

    try:
        l1 = FCLayer(2, 2, optimizer)
        l1.W = np.array([[2, 0], [0, 3]])
        l1.b = np.zeros(l1.b.shape)
        l2 = FCLayer(2, 1, optimizer)
        l2.W = np.array([[1], [1]])
        l2.b = np.ones(l2.b.shape)
        for r in np.random.random(size=(100, 2)):
            assert(l2.forward(l1.forward(r)) == r[0] * 2 + r[1] * 3 + 1) 
        print("Passed Simple Forward Value Check.")
    except:
        print("Failed Simple Forward Value Check. "
              "Hint: Check accuracy of your predictions. "
              "Your forward equation might be incorrect.")


def check2():
    try:
        delta = 1e-10
        above = mean_squared_error_loss(5 + delta, 1)
        below = mean_squared_error_loss(5 - delta, 1)
        assert (np.isclose([(above - below) / (2 * delta)],
                           [mean_squared_error_loss_derivative(5, 1)]))
        print("Passed Mean Squared Error Loss Gradient Check.")
    except:
        print("Failed Mean Squared Error Loss Gradient Check. "
              "Hint: Check your MSE/GradMSE implementations.")


def check3():
    optimizer = VanillaGradientDescent(lr=0.1)
    try:
        x = np.array([[1, 1]])
        l1 = FCLayer(2, 2, optimizer)
        l2 = FCLayer(2, 1, optimizer)

        l1.W = np.array([[0.0, 1.0], [1.0, 0.0]])
        l1.b = np.zeros(l1.b.shape)
        l2.W = np.array([[1.0], [1.0]])
        l2.b = np.zeros(l2.b.shape)

        out1 = l1.forward(x)
        out2 = l2.forward(out1)

        mse = mean_squared_error_loss_derivative(out2, 2)
        delta2 = l2.backward(mse)
        delta1 = l1.backward(delta2)

        assert (np.allclose(delta2, 0))
        assert (np.allclose(delta1, 0))

        out1 = l1.forward(x + np.array([[0, 0.01]]))
        out2 = l2.forward(out1)

        mse = mean_squared_error_loss_derivative(out2, 2.1)
        delta2 = l2.backward(mse)
        delta1 = l1.backward(delta2)

        assert(np.allclose(delta2, -0.09, rtol=0.001))
        assert(np.allclose(delta1, -0.09, rtol=0.001))

        print("Passed Simple Backward Check.")
    except:
        print("Failed Simple Backward Check. Hint: Verify that "
              "your backward equations and delta calculations are "
              "correct.")

    try:
        x = np.array([[0.03993786, 0.64987587, 0.86168613, 0.63255467, 0.36027018,
                       0.04978609, 0.61788469, 0.09792505, 0.83025406, 0.90049985]])
        l1 = FCLayer(10, 15, optimizer)
        l2 = FCLayer(15, 5, optimizer)
        l3 = FCLayer(5, 1, optimizer)

        l1.W = np.array([[0.49739087, 0.01456936, 0.05072057, 0.33451292, 0.98898759,
                          0.30069394, 0.70673725, 0.63908046, 0.66677376, 0.48860228,
                          0.17996713, 0.2613659, 0.51429802, 0.1827823, 0.8584029],
                         [0.41542834, 0.54412737, 0.23088827, 0.61304553, 0.69770366,
                          0.3124046, 0.67479274, 0.65902889, 0.12651837, 0.12286503,
                          0.96896209, 0.14655556, 0.80327037, 0.56228915, 0.30991579],
                         [0.25443077, 0.96854947, 0.64942842, 0.43811253, 0.90091334,
                          0.9049289, 0.5547828, 0.62242034, 0.48110664, 0.5058829,
                          0.97474188, 0.69278375, 0.84140159, 0.73129589, 0.77939175],
                         [0.64720563, 0.98158199, 0.18369936, 0.67921916, 0.00952322,
                          0.08765346, 0.89933113, 0.58807789, 0.09810089, 0.37482276,
                          0.45935977, 0.0472633, 0.84307282, 0.10466161, 0.62836689],
                         [0.90105395, 0.5767814, 0.65995126, 0.63203093, 0.15968684,
                          0.40087703, 0.31782319, 0.31587108, 0.27485808, 0.74960168,
                          0.48824479, 0.59040529, 0.07954757, 0.5624092, 0.72947296],
                         [0.13508363, 0.50541094, 0.3985369, 0.44442131, 0.7721487,
                          0.98757206, 0.74054794, 0.68342705, 0.89406768, 0.85316022,
                          0.21458418, 0.42751464, 0.29571873, 0.95228596, 0.13417271],
                         [0.07472199, 0.47076261, 0.50186672, 0.13889074, 0.64476796,
                          0.31348729, 0.15473013, 0.09623553, 0.09593534, 0.1066171,
                          0.32248734, 0.07832945, 0.89875032, 0.88107104, 0.7541968],
                         [0.87380384, 0.32129189, 0.88514311, 0.47890941, 0.97852401,
                          0.49724257, 0.18351818, 0.47542718, 0.44821001, 0.28078577,
                          0.27196587, 0.85699439, 0.4864818, 0.10719826, 0.72498704],
                         [0.02599203, 0.34465254, 0.16627698, 0.16223412, 0.69317748,
                          0.30685331, 0.72477298, 0.30614572, 0.81664174, 0.69080034,
                          0.1051027, 0.01098006, 0.00432411, 0.85311475, 0.73791918],
                         [0.29584841, 0.05998718, 0.1050482, 0.92741798, 0.51506401,
                          0.59547464, 0.24538412, 0.73945182, 0.57062144, 0.80337227,
                          0.94471682, 0.73665349, 0.78495283, 0.74304276, 0.10428187]])

        l1.b = np.zeros(l1.b.shape)

        l2.W = np.array([[0.27220596, 0.20669153, 0.63616059, 0.06558849, 0.10400932],
                         [0.84177499, 0.30947968, 0.98848695, 0.63415702, 0.14175905],
                         [0.28472295, 0.70811939, 0.81930279, 0.9162889, 0.78857237],
                         [0.49259379, 0.03924127, 0.30780401, 0.65145601, 0.64728453],
                         [0.87547659, 0.39139067, 0.67215652, 0.82069468, 0.91030675],
                         [0.09193133, 0.23238672, 0.77194635, 0.5842018, 0.97645803],
                         [0.61773038, 0.3818436, 0.72461408, 0.93176455, 0.89536155],
                         [0.75301851, 0.39069713, 0.12876179, 0.72421074, 0.61439624],
                         [0.04033057, 0.6653774, 0.00917634, 0.20022594, 0.54376972],
                         [0.67115491, 0.48128505, 0.33427871, 0.71606501, 0.57603462],
                         [0.82273419, 0.22376086, 0.03672288, 0.83495334, 0.0702379],
                         [0.59784719, 0.09638346, 0.95683602, 0.21283411, 0.48401833],
                         [0.30446772, 0.32996783, 0.04776068, 0.89263799, 0.23896182],
                         [0.46095267, 0.32710095, 0.06178846, 0.86127416, 0.21086896],
                         [0.35785547, 0.75834178, 0.22567877, 0.88032092, 0.02468932]])

        l2.b = np.zeros(l2.b.shape)

        l3.W = np.array([[0.56717934],
                         [0.78926619],
                         [0.90879682],
                         [0.52518045],
                         [0.78143687]])

        l3.b = np.zeros(l3.b.shape)

        out1 = l1.forward(x)
        out2 = l2.forward(out1)
        out3 = l3.forward(out2)

        mse = mean_squared_error_loss_derivative(out3, np.array([[60]]))
        delta3 = l3.backward(mse)
        delta2 = l2.backward(delta3)
        delta1 = l1.backward(delta2)

        assert(np.allclose(delta3, [[ 2.00121373,  2.78481642,  3.20656369,  1.85302647,
                                     2.75719175]]))
        assert(np.allclose(delta2, [[ 3.56854056,  7.28202874,  9.04107336,  5.07391114,  
                                     9.02793884,  7.08124714, 8.81836389,  6.04384355,  
                                     3.83338986,  6.67042622,  4.12820412,  6.26190447, 
                                     3.99429785, 4.20887951,  5.25097242]]))
        assert(np.allclose(delta1, [[ 40.71528404,  42.51233018,  63.36304155,  38.9322806,   
                                     43.86295931, 53.2206626,   33.08298325,  49.01883566,  
                                     37.32528652,  45.51702899]]))
        print("Passed Multi-Layer more 'Complex' Backward Check.")
    except:
        print("Failed Multi-Layer more 'Complex' Backward Check. Hint: Verify "
              "that your backward equations and delta calculations are correct. Also maybe "
              "check multi-layer related problems.")


def run_all_checks():
    try:
        check1()
        check2()
        check3()
        print("All Checks Passed!")
    except:
        print("Some Check Failed. Run Individual checks to get more "
              "detailed information.")