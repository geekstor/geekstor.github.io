# EECS 445 Homework 6: Neural Networks and Deep Learning
# File: activations.py
# Contents: Functions used to add non-linearities to Neural Networks,
#           i.e., Activation Functions, as well as their gradients for
#           running backpropagation.

import numpy as np


def linear_activation(x):
    """
    --> Task 1 (a) <--
    Linear Activation Function.
    :param x: input.
    :return: LinearActivation(x)
    """
    return x


def linear_activation_derivative(x):
    """
    --> Task 1 (a) <--
    Derivative of Linear Activation
    :param x: input.
    :return: DerivativeOfLinearActivation(x)
    """
    return np.ones_like(x)


def sigmoid_activation(x):
    """
    --> Task 4 (c) <--
    Sigmoid (Logistic) Activation Function.
    :param x: input.
    :return: Sigmoid(x).
    """

    # Clipping to truncate to reasonable range for sigmoid
    # (avoid Underflow and Overflow)
    x = np.clip(x, -500, 500)

    return 1 / (1 + np.exp(-x))


def sigmoid_activation_derivative(x):
    """
    --> Task 4 (c) <--
    Derivative Of Sigmoid Activation Function.
    :param x: input.
    :return: DerivativeOfSigmoid(x)

    Note: This function will look different depending on
          whether you cache activations and use them or use the
          "pre-activation" input and run the sigmoid
          activation function again. So, be sure to pass the
          correct input and check that it matches with the way
          the derivative is computed here.
    """
    return sigmoid_activation(x) * sigmoid_activation(1 - x)


def tanh_activation(x):
    """
    --> Task 4 (c) <--
    Hyperbolic Tangent Activation Function.
    :param x: input.
    :return:Tanh(x)
    """
    return np.tanh(x)


def tanh_activation_derivative(x):
    """
    --> Task 4 (c) <--
    Hyperbolic Tangent Activation Function Derivative.
    :param x: input.
    :return:DerivativeOfTanh(x)

     Note: This function will look different depending on
          whether you cache activations and use them or use the
          "pre-activation" input and run the Tanh
          activation function again. So, be sure to pass the
          correct input and check that it matches with the way
          the derivative is computed here.
    """
    return 1 - tanh_activation(x) ** 2


def relu_activation(x):
    """
    --> Task 4 (c) <--
    :param x: input.
    :return: ReLU(x) = x if x > 0, else 0
    """

    # Clip values so that the minimum value is 0. In other words, this does max(0, x).
    return x.clip(min=0)


def relu_activation_derivative(x):
    """
    --> Task 4 (c) <--
    :param x: input.
    :return: DerivativeOfReLU(x).
    """

    # Get a Boolean NumPy array containing whether each element is greater than 0
    # and convert to float to ensure the network always works with float arrays
    return np.array(x > 0).astype(np.float)


activation_fns = {
    'linear': (linear_activation, linear_activation_derivative),
    'relu': (relu_activation, relu_activation_derivative),
    'sigmoid': (sigmoid_activation, sigmoid_activation_derivative),
    'tanh': (tanh_activation, tanh_activation_derivative)
}
