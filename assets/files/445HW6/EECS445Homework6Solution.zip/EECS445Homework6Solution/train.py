# File: train.py
# Contents: Manager class to abstract training and evaluation. Some starter code for
# writing training loops and using the powerful FCLayer, SoftMaxLayer, and
# MLP abstractions that form the Neural Networks of this assignment.

import numpy as np

from optim import *
from loss_functions import loss_fns
from multi_layer_perceptron import MLP

from layers import FCLayer

# Confusion Matrices are a common classification performance analysis tool.
# Essentially it is a matrix which allows one to see how often examples from a certain class, say,
# C_i, was correctly classified as C_i, or misclassified as some other class C_k, k != i.
# See https://en.wikipedia.org/wiki/Confusion_matrix for more.
from sklearn.metrics import confusion_matrix


class Manager(object):
    def __init__(self, net):
        """
        --> Task 3 (b) <--
        :param net: a Neural Net
        (we only will be concerned MLP objects.)
        """
        self.net = net

    def train(self, x, y, batch_sz, nb_iters):
        """
        --> Task 3 (b) <--
        Train an ANN using minibatch gradient descent.
        :param x: entire training set data.
        :param y: entire training set targets or labels.
        :param batch_sz: batch size to use for a train step.
        :param nb_iters: number of times to run a train step.
        :return: None
        """

        for i in range(nb_iters):
            idx = np.random.randint(len(x), size=batch_sz)
            sample = x[idx]
            target = np.array([y[i] for i in idx])
            self.net.forward(sample)
            self.net.backward(target)

    def eval(self, x):
        """
        --> Task 3 (b) <--
        :param x: input.
        :return: predictions.
        """
        return self.net.forward(x)


# NOTE: The code below for the training functions illustrates a very basic minimum analysis.
# For plots and for incorporating stopping conditions based on the loss, one nice way to go
# about using the Manager abstraction is running just a few iterations of training, then,
# running eval and collecting information such as the loss on the test or validation sets
# or some portion thereof.

def train_averaging():
    """
    --> Task 2 <--
    Follow the instructions given below.
    :return: None
    """
    print("-- Averaging Test --")
    np.random.seed(0)
    x = np.random.randint(low=0, high=100, size=(1000, 5))
    y = x.mean(axis=1)

    # Create a FCLayer object, and using a loop (with forward/backward)
    # as appropriate, train the Fully Connected layer with batches of
    # 10 examples. Train until the change in the mean squared error
    # is minimal (say less than 1e-5).
    l = FCLayer(fan_in=5, fan_out=1, activation_fn='linear',
                optimizer=VanillaGradientDescent(lr=1e-5))

    prev_mse = None
    curr_mse = np.finfo(np.float32).max

    loss = loss_fns['MSE'][0]
    loss_deriv = loss_fns['MSE'][1]

    while prev_mse is None or np.abs(prev_mse - curr_mse) > 1e-5:
        idx = np.random.randint(len(x), size=10)
        sample = x[idx]
        target = np.array([[y[i]] for i in idx])
        out = l.forward(sample)
        prev_mse = curr_mse
        curr_mse = loss(out, target)
        l.backward(loss_deriv(out, target))

    np.random.seed(1000)
    x = np.random.randint(low=0, high=100, size=(1000, 5))

    #  Get the outputs given the above inputs.
    out = l.forward(x)
    y = x.mean(axis=1)

    print("Weights: ", l.W.squeeze())
    print("Bias: ", l.b.squeeze())

    # Calculate the errors here (you can use MSE loss) and
    # print the average loss.
    print("Test Loss: ", loss(out, np.array([y]).T))
    print("--------------------\n\n")


def train_XOR(net):
    """
    --> Task 4 (a) <--
    Using the network given (the net argument), create a Manager,
    and use the data given below to train a XOR function. Create plots
    to see if the network is learning well. Note: you should
    repeat the data given with shuffling to get a larger dataset.
    (and the corresponding targets along in a similar manner).
    :return: None
    """
    print("-- XOR Preds. -- ")

    x = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
    t = np.array([[1, 0], [0, 1], [0, 1], [1, 0]])

    manager = Manager(net)

    manager.train(x, t, batch_sz=25, nb_iters=1000)

    y = manager.eval(x)
    print("Loss: ", manager.net.loss(y, t))

    print("Prediction probs. for [0, 0]: ", np.squeeze(manager.eval([[0, 0]])))
    print("Prediction probs. for [0, 1]: ", np.squeeze(manager.eval([[0, 1]])))
    print("Prediction probs. for [1, 0]: ", np.squeeze(manager.eval([[1, 0]])))
    print("Prediction probs. for [1, 1]: ", np.squeeze(manager.eval([[1, 1]])))
    print("---------------\n\n")


def train_MNIST(net):
    print("-- Average Accuracy of MNIST Classification --")

    from sklearn.datasets import fetch_mldata

    mnist = fetch_mldata("MNIST original")
    X, t = mnist.data / 255., mnist.target
    X_train, X_test = X[:60000], X[60000:]
    t_train, t_test = t[:60000], t[60000:]

    t_train_1hot = np.array([[1 if j == i else 0 for i in range(10)] for j in t_train])
    t_test_1hot = np.array([[1 if j == i else 0 for i in range(10)] for j in t_test])

    manager = Manager(net)
    manager.train(X_train, t_train_1hot, 25, 7500)

    y_train = manager.eval(X_train)
    print("Train Loss: ", manager.net.loss(y_train, t_train_1hot))
    print("Train Accuracy: ",
          np.sum(np.argmax(y_train, axis=1) == t_train.flatten()) / len(t_train))
    print("Train Set Confusion Matrix:\n",
          confusion_matrix(t_train.flatten(), np.argmax(y_train, axis=1)))

    y_test = manager.eval(X_test)
    print("Test Loss: ", manager.net.loss(y_test, t_test_1hot))
    print("Test Accuracy: ",
          np.sum(np.argmax(y_test, axis=1) == t_test.flatten()) / len(t_test))
    print("Test Set Confusion Matrix:\n",
          confusion_matrix(np.argmax(y_test, axis=1), t_test.flatten()))

    print("----------------------------------------------")


# Running the training functions.
train_averaging()

train_XOR(MLP(n_inputs=2, n_out=2, n_hid=[5],
          loss='XEnt', optim=VanillaGradientDescent(lr=2.5),
          classifier=True, act_fns=['sigmoid']))

train_MNIST(MLP(n_inputs=784, n_out=10, n_hid=[500, 250],
            loss='XEnt', optim=MomentumGradientDescent(lr=0.025, momentum=0.90),
            classifier=True, act_fns=['sigmoid', 'sigmoid']))

# ------------------- OUTPUT (May differ depending on Random Seeds) ------------------- #
# After Such Anticipation, Much Time (~ 5 min.), we get all the results:
#
# -- Averaging Test --
# Weights:  [ 0.20082572  0.19552025  0.19607887  0.19967126  0.199716  ]
# Bias:  0.40944168359792954
# Test Loss:  0.0152253820897
# --------------------
#
#
# -- XOR Preds. --
# Loss:  0.00212969550332
# Prediction probs. for [0, 0]:  [  9.99497166e-01   5.02834420e-04]
# Prediction probs. for [0, 1]:  [ 0.00208833  0.99791167]
# Prediction probs. for [1, 0]:  [ 0.0016775  0.9983225]
# Prediction probs. for [1, 1]:  [ 0.9957626  0.0042374]
# ---------------
#
#
# -- Average Accuracy of MNIST Classification --
# Train Loss:  0.0703291762877
# Train Accuracy:  0.979633333333
# Train Set Confusion Matrix:
#  [[5842    0    3    6    2   10   43    0   13    4]
#  [   1 6649   34   11    8    3    7    4   22    3]
#  [   8    2 5850   21   15    4   30    7   16    5]
#  [   3    2   34 6004    0   28   10    6   34   10]
#  [   2    4   10    4 5705    2   57    2   12   44]
#  [   2    2    3   42    5 5292   51    1   13   10]
#  [   7    2    0    0    2    6 5897    0    4    0]
#  [   4   10   62   38   27    2   10 6043   12   57]
#  [   8    7   22   30    0   23   30    1 5723    7]
#  [   8    9    3   32   55   12    2   15   40 5773]]
# Test Loss:  0.144911011168
# Test Accuracy:  0.957
# Test Set Confusion Matrix:
#  [[ 947    0    4    1    0    2    4    1    2    2]
#  [   0 1119    0    0    0    1    2    4    0    2]
#  [   2    7  997    5    6    2    2   28   10    8]
#  [   0    0    6  976    0   20    0    7    7    8]
#  [   1    0    2    1  931    1    2    7    3   20]
#  [   5    0    1    9    1  842    5    1    8    9]
#  [  18    4    8    0   19   13  939    2   10    3]
#  [   1    1    5    3    2    0    0  953    3    9]
#  [   4    4    9   13    4    9    4    9  929   11]
#  [   2    0    0    2   19    2    0   16    2  937]]
# ----------------------------------------------
#
# Process finished with exit code 0
# ------------------------------------------------------------------------------------- #
