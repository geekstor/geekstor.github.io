# File: multi_layer_perceptron.py
# Contents: Contains MLP class to abstract a multi-layer network composed of Fully Connected
# layers, optionally with a SoftMax layer for classification problems. This file is largely left
# unfilled. However, given that FCLayer is implemented, the code for this class is
# largely an exercise in exceptions, conditionals, iterations, and some OOP.

from layers import *
from loss_functions import loss_fns


class MLP(object):
    def __init__(self, n_inputs, n_hid, n_out, optim, loss,
                 act_fns=None, classifier=False):
        """
        --> Task 3 (a) <--
        Note: i. For this question, the main idea is to store
              something like a list of FCLayer objects and use loops
              for forward and backward as necessary.
              ii. If the act_fns list is None, you can use the default
                  (no need to fill the activation_fn parameter on init.
                   of an FCLayer.)
        :param n_inputs: number of inputs.
        :param n_hid: list of numbers signifying the number of neurons in
                      hidden layers (if any.)
        :param n_out: number of outputs.
        :param optim: an optimizer object.
        :param loss: a string signifying the loss function to be used
                     (see loss_fns in loss_functions.py)
        :param act_fns: a list of activation functions
                to use after each layer (specified as a list of strings,
                see activation_fns in activation_functions.py)
        :param classifier: set to True to add a SoftMax Layer as the last
                last layer of the MLP
        """
        self.layers = []

        if type(n_hid) is not list:
            raise Exception("Please use a list to specify the hidden "
                            "layer dimensions, use an empty list if no "
                            "hidden layers are needed.")

        if type(act_fns) is not list and act_fns is not None:
            raise Exception("Please use a list to specify the activation "
                            "functions after each layer.")

        if type(act_fns) is list and len(act_fns) != len(n_hid):
            raise Exception("Expected size for activation functions list does "
                            "not match the size of the given activation functions "
                            "list.")

        if len(n_hid) == 0:
            if act_fns is None:
                self.layers.append(FCLayer(fan_in=n_inputs, fan_out=n_out, optimizer=optim,
                                           activation_fn='linear'))
            else:
                self.layers.append(FCLayer(fan_in=n_inputs, fan_out=n_out, optimizer=optim,
                                           activation_fn=act_fns[-1]))

        else:
            # print("Adding layer", n_inputs, n_hid[0])
            self.layers.append(FCLayer(fan_in=n_inputs, fan_out=n_hid[0], optimizer=optim,
                                       activation_fn=act_fns[0] if type(act_fns) is list else
                                       'linear'))
            for i in range(1, len(n_hid)):
                # print("Adding layer", n_hid[i - 1], n_hid[i])
                self.layers.append(FCLayer(fan_in=n_hid[i - 1], fan_out=n_hid[i], optimizer=optim,
                                           activation_fn=act_fns[i] if type(act_fns) is list else
                                           'linear'))
            # print("Adding layer", n_hid[-1], n_out)
            self.layers.append(FCLayer(fan_in=n_hid[-1], fan_out=n_out,
                                       optimizer=optim, activation_fn='linear'))

        if classifier:
            self.layers.append(SoftMaxLayer())

        self.loss = loss_fns[loss][0]
        self.loss_derivative = loss_fns[loss][1]

        self._output = None

    def forward(self, x):
        """
        --> Task 3 (a) <--
        :param x: input.
        :return: output = forwarded input = MLP(x; parameters)
        """
        curr_in = x
        for l in self.layers:
            curr_in = l.forward(curr_in)
        self._output = curr_in
        return self._output

    def backward(self, t):
        """
        --> Task 3 (a) <--
        :param t: targets
        :return: None
        """
        curr_delta = self.loss_derivative(self._output, t)
        for l in reversed(self.layers):
            curr_delta = l.backward(curr_delta)
        self._output = None
