# EECS 445 Homework 6: Neural Networks and Deep Learning
# File: activations.py
# Contents: Functions used to add non-linearities to Neural Networks,
#           i.e., Activation Functions, as well as their gradients for
#           running backpropagation.

import numpy as np

def linear_activation(x):
    """
    --> Task 1 (a) <--
    Linear Activation Function.
    :param x: input.
    :return: LinearActivation(x)
    """
    raise NotImplementedError


def linear_activation_derivative(x):
    """
    --> Task 1 (a) <--
    Derivative of Linear Activation
    :param x: input.
    :return: DerivativeOfLinearActivation(x)
    """
    raise NotImplementedError


def sigmoid_activation(x):
    """
    --> Task 4 (c) <--
    Sigmoid (Logistic) Activation Function.
    :param x: input.
    :return: Sigmoid(x).
    """
    raise NotImplementedError


def sigmoid_activation_derivative(x):
    """
    --> Task 4 (c) <--
    Derivative Of Sigmoid Activation Function.
    :param x: input.
    :return: DerivativeOfSigmoid(x)

    Note: This function will look different depending on
          whether you cache activations and use them or use the
          "pre-activation" input and run the sigmoid
          activation function again. So, be sure to pass the
          correct input and check that it matches with the way
          the derivative is computed here.
    """
    raise NotImplementedError


def tanh_activation(x):
    """
    --> Task 4 (c) <--
    Hyperbolic Tangent Activation Function.
    :param x: input.
    :return:Tanh(x)
    """
    raise NotImplementedError


def tanh_activation_derivative(x):
    """
    --> Task 4 (c) <--
    Hyperbolic Tangent Activation Function Derivative.
    :param x: input.
    :return:DerivativeOfTanh(x)

     Note: This function will look different depending on
          whether you cache activations and use them or use the
          "pre-activation" input and run the Tanh
          activation function again. So, be sure to pass the
          correct input and check that it matches with the way
          the derivative is computed here.
    """
    raise NotImplementedError


def relu_activation(x):
    """
    --> Task 4 (c) <--
    :param x: input.
    :return: ReLU(x) = x if x > 0, else 0
    """
    raise NotImplementedError


def relu_activation_derivative(x):
    """
    --> Task 4 (c) <--
    :param x: input.
    :return: DerivativeOfReLU(x).
    """
    raise NotImplementedError


activation_fns = {
    'linear': (linear_activation, linear_activation_derivative),
    'relu': (relu_activation, relu_activation_derivative),
    'sigmoid': (sigmoid_activation, sigmoid_activation_derivative),
    'tanh': (tanh_activation, tanh_activation_derivative)
}
