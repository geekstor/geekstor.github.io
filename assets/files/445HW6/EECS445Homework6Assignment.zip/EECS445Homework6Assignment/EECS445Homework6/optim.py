class VanillaGradientDescent(object):
    def __init__(self, lr):
        self.lr = lr

    def get_parameter_update(self, x, dx, last_update=None):
        """
        --> Task 1 (d) <--
        :param x: parameter to update.
        :param dx: proposed parameter update (gradient of loss
                   w.r.t. parameter)
        :param last_update: unused (added to maintain polymorphism)
        :return: updated parameter using dx and the learning rate.
        """
        raise NotImplementedError


class MomentumGradientDescent(object):
    def __init__(self, lr, momentum):
        """
        --> Task 5 (a) <--
        :param lr: learning rate (gamma.)
        :param momentum: momentum parameter (nu.)
        """
        self.lr = lr
        self.momentum = momentum

    def get_parameter_update(self, x, dx, last_update):
        raise NotImplementedError
