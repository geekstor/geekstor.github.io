import numpy as np


def cross_entropy_loss(y, t):
    """
    --> Task 4 (b) <--
    Calculate the XEnt Loss given a prediction and
    a target.
    :param y: prediction of a neural net.
    :param t: target.
    :return: the XEnt loss given (y, t)
    """
    raise NotImplementedError


def cross_entropy_loss_derivative(y, t):
    """
    --> Task 4 (b) <--
    Calculate the gradient of the XEnt Loss given a prediction and
    a target, with respect to the prediction.
    :param y: prediction of a neural net.
    :param t: target.
    :return: grad_y XEnt given (y, t)
    """
    raise NotImplementedError


def mean_squared_error_loss(y, t):
    """
    --> Task 1 (c) <--
    Calculate the Mean Squared Error Loss given a prediction and
    a target.
    :param y: prediction of a neural net.
    :param t: target.
    :return: the MSE loss given (y, t).
    """
    raise NotImplementedError


def mean_squared_error_loss_derivative(y, t):
    """
    --> Task 1 (c) <--
    Calculate the gradient of the Mean Squared Error Loss
    given a prediction and target with respect to the prediction.
    :param y: prediction of a neural net.
    :param t: target.
    :return: grad_y MSE given (y, t).
    """
    raise NotImplementedError

loss_fns = {
    'XEnt' : (cross_entropy_loss, cross_entropy_loss_derivative),
    'MSE' : (mean_squared_error_loss, mean_squared_error_loss_derivative),
}