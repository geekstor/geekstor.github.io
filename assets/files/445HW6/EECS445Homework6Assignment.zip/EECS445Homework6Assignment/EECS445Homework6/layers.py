import numpy as np

from activations_functions import activation_fns


class FCLayer(object):
    def __init__(self, fan_in, fan_out, optimizer, activation_fn='linear'):
        self.W = 2 * np.random.random((fan_in, fan_out)) - 1
        self.b = np.random.random((1, fan_out))

        self.activation = activation_fns[activation_fn][0]
        self.activation_derivative = activation_fns[activation_fn][1]

        self.optimizer = optimizer

        self._input = None
        self._output = None
        self.last_update = None

    def forward(self, x):
        """
        --> Task 1 (b) <--
        Perform a forward step on the input with the Weights (W),
        biases (b) and activation function that define this FCLayer.
        :param x: input to forward step.
        :return: output of the forward step.
        """
        raise NotImplementedError

    def backward(self, delta):
        """
        --> Task 1 (e) <--
        Returns delta for next layer AND updates the weights and biases.
        (Other implementations where the parameters of a network are updated
        all together using a separate update() method are possible, but to make
        things easier, we do both the backprop calc. and update in backward
        itself.) 
        
        ** Remember to use the optimizer and update parameters. Also, ensure
        the delta you return uses the current weights and biases (i.e.,
        before the update to parameters.) **
        
        ** Also, following defensive programming, set the _input and _output
        member variables to a sentinel value (like None). **
        
        :param delta: previous layer's delta (when looking backward), i.e.,
                      next layer's delta (when looking forward)
        :return: delta for next layer (when looking backward), i.e.,
                 delta for previous layer (when looking forward)
        """
        raise NotImplementedError
