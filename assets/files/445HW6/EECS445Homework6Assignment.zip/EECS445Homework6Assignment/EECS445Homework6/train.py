import numpy as np

from optim import *
from multi_layer_perceptron import MLP


class Manager(object):
    def __init__(self, net):
        """
        --> Task 3 (b) <--
        :param net: a Neural Net
        (we only will be concerned MLP objects.)
        """
        pass

    def train(self, x, y, batch_sz, nb_iters):
        """
        --> Task 3 (b) <--
        Train an ANN using minibatch gradient descent.
        :param x: entire training set data.
        :param y: entire training set targets or labels.
        :param batch_sz: batch size to use for a train step.
        :param nb_iters: number of times to run a train step.
        :return: None
        """
        pass

    def eval(self, x):
        """
        --> Task 3 (b) <--
        :param x: input.
        :return: predictions.
        """
        pass


def train_averaging():
    """
    --> Task 2 <--
    Follow the instructions given below.
    :return: None
    """
    np.random.seed(0)
    x = np.random.randint(low=0, high=100, size=(1000, 5))
    y = x.mean(axis=1)

    # Create a FCLayer object, and using a loop (with forward/backward)
    # as appropriate, train the Fully Connected layer with batches of
    # 10 examples. Train until the change in the mean squared error
    # is minimal (say less than 1e-1).

    np.random.seed(1000)
    x = np.random.randint(low=0, high=100, size=(1000, 5))

    #  Get the outputs given the above inputs.

    y = x.mean(axis=1)

    # Calculate the errors here (you can use MSE loss) and
    # print the average loss.

    raise NotImplementedError


def train_XOR(net):
    """
    --> Task 4 (a) <--
    Using the network given (the net argument), create a Manager,
    and use the data given below to train a XOR function. Create plots
    to see if the network is learning well. Note: you should
    repeat the data given with shuffling to get a larger dataset.
    (and the corresponding targets along in a similar manner).
    :return: None
    """
    x = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
    y = np.array([[0], [1], [1], [0]])
    raise NotImplementedError


def train_MNIST(net):
    from sklearn.datasets import fetch_mldata

    mnist = fetch_mldata("MNIST original")
    X, y = mnist.data / 255., mnist.target
    X_train, X_test = X[:60000], X[60000:]
    y_train, y_test = y[:60000], y[60000:]
    raise NotImplementedError
