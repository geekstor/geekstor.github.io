from layers import *
from loss_functions import loss_fns

class MLP(object):
    def __init__(self, n_inputs, n_hid, n_outputs, optim, loss,
                 act_fns=None):
        """
        --> Task 3 (a) <--
        Note: i. For this question, the main idea is to store
              something like a list of FCLayer objects and use loops
              for forward and backward as necessary.
              ii. If act_fns is None, you can use the default, 'linear'
                  (no need to fill the activation_fn parameter on init.
                   of an FCLayer.)
        :param n_inputs: number of inputs.
        :param n_hid: list of numbers signifying the number of neurons in
                      hidden layers (if any.)
        :param n_outputs: number of outputs.
        :param optim: an optimizer object.
        :param loss: a string signifying the loss function to be used
                     (see loss_fns in loss_functions.py)
        :param act_fns: a list of activation functions
                to use after each layer (specified as a list of strings,
                see activation_fns in activation_functions.py)
        """
        raise NotImplementedError

    def forward(self, x):
        """
        --> Task 3 (a) <--
        :param x: input.
        :return: output = forwarded input = MLP(x; parameters)
        """
        raise NotImplementedError

    def backward(self, y):
        """
        --> Task 3 (a) <--
        Run a train step and update all parameters using backward() calls
        as appropirate for each of the layers in this MLP.
        :param y: targets for previously passed x to forward.
        :return: None
        """
        raise NotImplementedError
