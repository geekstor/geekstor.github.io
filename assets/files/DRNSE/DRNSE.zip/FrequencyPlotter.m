dontCloseFigs = [];
for param = {'g_Na', 'g_KDR',  'g_Leak', ... 
        'g_T',  'g_L',  'g_BK', ...
        'g_N',  'g_A',  'g_H', ...
        'g_SK'; 0.7509, 0.0548, 0.0019688, 0.11534, 0.0165, 0.003225, ...
        0.1883, 0.4277, 0.0023, 0.004833}

    p_name = cell2mat(param(1));
    p_def = cell2mat(param(2));
    conds = [];
    freqs = [];

    min_ = p_def * 0.5;
    true = p_def;
    max_ = p_def * 1.5;
    
    disp(p_name)
    disp([min_, true, max_])

    for i = min_:true/50:true
        [~, ~, te] = HH(p_name, i);
        d = diff(te);
        if numel(d) > 0
            conds = [conds i];
            freqs = [freqs 1000/d(end)];
        end
        close(setdiff(get(0,'children'),dontCloseFigs))
    end

    [~, ~, te] = HH(p_name, true);
    d = diff(te);
    conds = [conds true];
    freq_true = 1000/d(end);
    freqs = [freqs freq_true];
    close(setdiff(get(0,'children'),dontCloseFigs))

    for i = true:true/50:max_
        [~, ~, te] = HH(p_name, i);
        d = diff(te);
        if numel(d) > 0
            conds = [conds i];
            freqs = [freqs 1000/d(end)];
        end
        close(setdiff(get(0,'children'),dontCloseFigs))
    end

    fig = figure;
    xlim([min(conds), max(conds)])
    ylim([min(freqs), min(max(freqs), 2)])
    hold on
    plot(conds, freqs)
    hold on
    plot(true, freq_true, '*', 'MarkerSize', 20)
    
    splitted_p_name = strsplit(p_name, '_');
    p_name_formatted = strcat(splitted_p_name(1), '_{', splitted_p_name(2), '}');
    
    xlabel(strcat(p_name_formatted, ' (uSiemens)'), 'FontSize', 20)
    ylabel('Frequency of Activation Spikes (Hz)', 'FontSize', 20)
    title(strcat('Freq. of Activation Spikes vs. Max. Conductance,', {' '}, p_name_formatted), 'FontSize', 20)
    dontCloseFigs = [dontCloseFigs fig];
    hold off
    figure
end