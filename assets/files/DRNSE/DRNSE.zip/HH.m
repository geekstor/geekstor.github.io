function [t,v,te] = HH(varargin)
p = inputParser;
tspan = [0 10000];
v0 = [-65;... % V_m_0
    0.05;... % m_A_0
    0.0474;... % h_A_0
    0.0016;... % n_0
    0.3813;... % m_T_0
    0.0052;... % h_T_0
    0.0085;... % m_L_0
    0.7478;... % h_L_0
    0.0067;... % m_N_0
    0.8176;... % h_N_0
    3.3535e-4;... % m_BK_0
    0.0385;... % m_SK_0
    0.0180;... % m_H_0
    0.0829;... % m_Na_0
    0.8164;... % h_Na_0
    0.00005... % Ca_i_0];
    ];
te = [];

 %Maximal conductances: Table 19
        addParameter(p, 'g_Na', 0.7509, @isnumeric)
        % g_Na = 0.7509;
        addParameter(p, 'g_KDR', 0.0548, @isnumeric)
        % g_KDR = 0.0548;
        
        % 1322.7
        
        addParameter(p, 'g_Leak', 0.0019688, @isnumeric)
        % g_Leak = 0.0019688;
        addParameter(p, 'g_T', 0.11534, @isnumeric)
        % g_T = 0.11534;
         addParameter(p, 'g_L', 0.0165, @isnumeric)
         % g_L = 0.0165;
         addParameter(p, 'g_BK', 0.003225, @isnumeric)
         % g_BK = 0.003225;
         addParameter(p, 'g_N', 0.1883, @isnumeric)
         % g_N = 0.1883;
         addParameter(p, 'g_A', 0.4277, @isnumeric)
         % g_A = 0.4277;
         addParameter(p, 'g_H', 0.0023, @isnumeric)
         % g_H = 0.0023;
         addParameter(p, 'g_SK', 0.00482, @isnumeric)
         % g_SK = 0.004833;
        
%        g_T = 0;
%        g_L = 0;
%        g_BK = 0;
%        g_N = 0;
%        g_A = 0;
%        g_H = 0;
%        g_SK = 0;

 %         u = -0.01; 
        addParameter(p, 'u', 0, @isnumeric)
       
          parse(p, varargin{:})
        
        g_Na = p.Results.g_Na;
        g_KDR = p.Results.g_KDR;
        g_Leak = p.Results.g_Leak;
        g_T =  p.Results.g_T;
        g_L = p.Results.g_L;
        g_BK = p.Results.g_BK;
        g_N = p.Results.g_N;
        g_A = p.Results.g_A;
        g_H = p.Results.g_H;
        g_SK = p.Results.g_SK;
        u = p.Results.u;

%     % Call the ODE solver ode15s.
%     options = odeset('MaxStep',1); % Might need to modify this, check article
%     [t,v] = ode15s(@hh,tspan,v0,options);

% % include option to save spike times: times in te, variables in ve, event
% % type in ie
options = odeset('Events',@spikes);
% options = odeset('Events',@spikes,'MaxStep',.008);
[t,v,te,ve,ie] = ode15s(@hh,tspan,v0,options);

figure
plot(t,v(:,1));
ylim([-80, 40])
legend(strcat('Applied Current: ', num2str(u * 1000), ' pA'))
title('V_{m}');

% compute conductances and currents
%     gna=120;
%     gk=36;
%     gl=0.3;
%     ena=50;
%     ek=-77;
%     el=-54.4;
vm = v(:,1);

m_A = v(:,2);
h_A = v(:,3);

n = v(:,4);

m_T = v(:,5);
h_T = v(:,6);

m_L = v(:,7);
h_L = v(:,8);

m_N = v(:,9);
h_N = v(:,10);

m_BK = v(:,11);

m_SK = v(:,12);

m_H = v(:,13);

m_Na = v(:,14);
h_Na = v(:,15);

Ca_i = v(:,16);

I_A = g_A .* m_A.^4 .* h_A .* (vm-V_K);
I_KDR = g_KDR .* n.^n_k .* (vm-V_K);
I_T = g_T .* m_T.^2 .* h_T .* (vm-V_Ca);
I_L = g_L .* m_L.^2 .* h_L .* (vm-V_Ca);
I_N = g_N .* m_N.^2 .* h_N .* (vm-V_Ca);
I_BK = g_BK .* m_BK .* (vm-V_K);
I_SK = g_SK .* m_SK .* (vm-V_K);
I_H = g_H .* m_H .* (vm-V_H);
I_Na = g_Na .* m_Na.^3 .* h_Na .* (vm-V_Na);
I_leak = g_Leak * (vm - V_leak);

figure;
subplot(2,2,1);
plot(t,I_A);
title('I_{A}');
subplot(2,2,2);
plot(t,I_KDR);
title('I_{KDR}');
subplot(2,2,3);
plot(t,I_T);
title('I_{T}');
subplot(2,2,4);
plot(t,I_L);
title('I_{L}');


figure;
subplot(2,2,1);
plot(t,I_N);
title('I_{N}');
subplot(2,2,2);
plot(t,I_BK);
title('I_{BK}');
subplot(2,2,3);
plot(t,I_SK);
title('I_{SK}');
subplot(2,2,4);
plot(t,I_H);
title('I_{H}');

figure;
subplot(2,2,1);
plot(t,I_Na);
title('I_{Na}');
subplot(2,2,2);
plot(t,I_leak);
title('I_{Leak}');
subplot(2,2,3);
plot(t,Ca_i);
title('Ca_{i}');

% Define the ODE function as nested function,
% using the parameter pulsei.
    function dV_dt = hh(t,v)
        % Load set A constants
        
        %Non-varying Parameters: Table 17
        V_Ca = 60;
        V_R = -60;
        V_Na = 45;
        V_H = -45;
        F = 96500;
        Ca_o = 2;
        Ca_i0 = 0.00005;
        d = 0.1;
        
        %Activation and inactivation parameters: Table 18
        V_Na1 = -34.76;
        k_Na1 = 10.5;
        a_Na = 0.05;
        b_Na = 0.15;
        V_Na2 = -40;
        k_Na2 = 7.85;
        V_Na3 =-50.3;
        k_Na3 = 6.5;
        c_Na = 0.5;
        d_Na = 7.5;
        V_Na4 = -43;
        k_Na4 = 6.84;
        V_KDR1 = -15;
        n_k = 1;
        k_KDR1 = 7;
        a_KDR = 0.5;
        b_KDR = 3.5;
        V_KDR2 = -20;
        k_KDR2 = 7;
        V_T1 = -57;
        k_T1 = 6.2;
        V_T3 = -81;
        k_T3 = 4;
        a_T = 0.7;
        b_T = 13.5;
        V_T2 = -57;
        k_T2 = 18;
        c_T = 28;
        d_T = 300;
        V_T4 = -81;
        k_T4 = 12;
        V_L1 = -20;
        k_L1 = 8.4;
        a_L = 0.5;
        b_L = 1.5;
        V_L2 = -20;
        k_L2 = 15;
        V_L3 = -45;
        k_L3 = 13.8;
        tau_hL = 200;
        V_N1 = -15;
        k_N1 = 9;
        a_N = 0.75;
        b_N = 1;
        V_N2 = -15;
        k_N2 = 15;
        V_N3 = -45;
        k_N3 = 10;
        tau_hN = 1000;
        V_A1 = -60;
        k_A1 = 8;
        V_A3 = -78;
        k_A3 = 6;
        a_A = 0.37;
        b_A = 2;
        V_A2 = -60;
        k_A2 = 12;
        c_A = 19;
        d_A = 45;
        V_A4 = -78;
        k_A4 = 7;
        V_H1 = -80;
        k_H1 = 5;
        a_H = 900;
        k_H2 = 13;
        V_H2 = -80;
        K_c = 0.00025;
        tau_mSK = 5;
        V_BK = -20;
        k_BK = 5;
        tau_BK = 1.25;
        
       
        
        %Cell properties and Ca dynamics: Table 20
        V_K = -93.0;
        R_in = 508;
        C = 0.03;
        A = 3500;
        V_leak = -61;
        B_tot = 0.03;
        K_d = 0.001;
        K_s = 7.3242*10^-7;
        CSF = 0.201;
        K_m = 0.00025;
        
        %For parameter set A:
        V_equil = -65; % see pg. 78, 1st paragraph
        
        vol = 2.5e-4; % ? =d?? = 2.5?10?4 nl, taken from Rybak et al 1997 % CHECK UNITS. Also, are respiratory neurons = in size to DRN?
        
        n_HC = 4;
        
        %     dvdt(1) = (-gna*(v(2)^3)*v(3)*(v(1)-ena)-gk*(v(4)^4)*(v(1)-ek)...
        %             -gl*(v(1)-el) + pulsei*heaviside(t-ton)*heaviside(toff-t))/c;
        %     dvdt(2) = alpham(v(1))*(1-v(2))-betam(v(1))*v(2);
        %     dvdt(3) = alphah(v(1))*(1-v(3))-betah(v(1))*v(3);
        %     dvdt(4) = alphan(v(1))*(1-v(4))-betan(v(1))*v(4);
        
        dV_dt(1) = (1/C)*(-(...
            (g_A*(v(2)^4)*v(3)*(v(1)-V_K))+... % I_A = g_A * m_A^4 * h_A * (V-V_A)
            (g_KDR*(v(4)^n_k)*(v(1)-V_K))+... % I_KDR = g_KDR * n^n_k * (V-V_KDR);
            (g_T * (v(5)^2) * v(6) * (v(1)-V_Ca))+... % I_T = g_T * m_T^2 * h_T * (V-V_Ca);
            (g_L * (v(7)^2) * v(8) * (v(1)-V_Ca))+... % I_L = g_L * m_L^2 * h_L * (V-V_Ca);
            (g_N * (v(9)^2) * v(10) * (v(1)-V_Ca))+... % I_N = g_N * m_N^2 * h_N * (V-V_Ca);
            (g_BK * v(11) * (v(1)-V_K))+... % I_BK = g_BK * m_BK * (V-V_K);
            (g_SK * v(12) * (v(1)-V_K))+... % I_SK = g_SK * m_SK * (V-V_K);
            (g_H * v(13) * (v(1)-V_H))+... % I_H = g_H * m_H * (V-V_H);
            (g_Na * (v(14)^3) * v(15) * (v(1)-V_Na))+... % I_Na = g_Na * m_Na^3 * h_Na * (V-V_Na);
            (g_Leak * (v(1) - V_leak))+... % I_leak = g_leak * (V - V_leak);
            u*heaviside(t)));
        % INSERT CALCIUM CURRENTS HERE I BELIEVE, SO THE RESULTS CAN BE CALLED IN
        % THE NESTED FUNCTIONS BELOW. ADD THEM TO THE V MATRIX FIRST THOUGH ABOVE
        dV_dt(16) = (-CSF*...
            ((g_L * (v(7)^2) * v(8) * (v(1)-V_Ca)) +...
            (g_N * (v(9)^2) * v(10) * (v(1)-V_Ca)))*...
            ((1-PB(v(16)))/(2*F*vol)))- ...
            (K_s*(v(16)/(v(16) + K_m))); % d_Ca_i_dt = (-CSF*(I_L+I_N)*((1-PB(t))/(2*F*v)))-(K_s*(Ca_i/(Ca_i + K_m)));
        dV_dt(2) = (m_A_inf(v(1))-v(2))/tau_mA(v(1)); % d_m_A/dt = (m_A_inf - m_A)/tau_m_A
        dV_dt(3) = (h_A_inf(v(1))-v(3))/tau_hA(v(1)); % d_h_A/dt
        dV_dt(4) = (n_inf(v(1))-v(4))/tau_n(v(1)); % dn_dt
        dV_dt(5) = (m_T_inf(v(1))-v(5))/tau_mT(v(1)); % dm_T/dt
        dV_dt(6) = (h_T_inf(v(1))-v(6))/tau_hT(v(1)); % dh_T/dt
        dV_dt(7) = (m_L_inf(v(1))-v(7))/tau_mL(v(1)); % dm_L/dt
        dV_dt(8) = (h_L_inf(v(1))-v(8))/tau_hL; % dh_L/dt
        dV_dt(9) = (m_N_inf(v(1))-v(9))/tau_mN(v(1)); % dm_N/dt
        dV_dt(10) = (h_N_inf(v(1))-v(10))/tau_hN; % dh_N/dt
        dV_dt(11) = (m_BK_inf(v(1))-v(11))/tau_BK; % dm_BK/dt
        dV_dt(12) = (m_SK_inf(v(16))-v(12))/tau_mSK; % dm_SK/dt
        % ABOVE DOESN'T ACTUALLY DEPEND ON V, JUST ON N GATING VARIABLE I THINK,
        % UPDATED NOW
        dV_dt(13) = (m_H_inf(v(1))-v(13))/T_m_H(v(1)); % dm_H/dt
        dV_dt(14) = (m_Na_inf(v(1))-v(14))/T_m_Na(v(1)); % dm_Na/dt
        dV_dt(15) = (h_Na_inf(v(1))-v(15))/T_h_Na(v(1)); % dh_Na/dt
        dV_dt=dV_dt';
        
        function im_A_inf = m_A_inf(V)
            im_A_inf = 1/(1+exp(-(V-V_A1)/k_A1));
        end
        
        function itau_mA = tau_mA(V)
            itau_mA = a_A + (b_A/cosh((V-V_A2)/k_A2));
        end
        
        function ih_A_inf = h_A_inf(V)
            ih_A_inf = 1/(1+exp((V-V_A3)/k_A3));
        end
        
        function itau_hA = tau_hA(V)
            itau_hA = c_A + (d_A/cosh((V-V_A4)/k_A4));
        end
        
        function in_inf = n_inf(V)
            in_inf = 1/(1+exp(-(V-V_KDR1)/k_KDR1));
        end
        
        function itau_n = tau_n(V)
            itau_n = a_KDR + (b_KDR/cosh((V-V_KDR2)/k_KDR2));
        end
        
        function im_T_inf = m_T_inf(V)
            im_T_inf = 1/(1+exp(-(V-V_T1)/k_T1));
        end
        
        function ih_T_inf = h_T_inf(V)
            ih_T_inf = 1/(1+exp((V-V_T3)/k_T3));
        end
        
        function itau_mT = tau_mT(V)
            itau_mT = a_T + (b_T/cosh((V-V_T2)/k_T2));
        end
        
        function itau_hT = tau_hT(V)
            itau_hT = c_T + (d_T*exp(-((V-V_T4)/k_T4))^2);
        end
        
        function im_L_inf = m_L_inf(V)
            im_L_inf = 1/(1+exp(-(V-V_L1)/k_L1));
        end
        
        function ih_L_inf = h_L_inf(V)
            ih_L_inf = 1/(1+exp((V-V_L3)/k_L3));
        end
        
        function itau_mL = tau_mL(V)
            itau_mL = a_L + (b_L/cosh((V-V_L2)/k_L2)); % Changed to +
        end
        
        function im_N_inf = m_N_inf(V)
            im_N_inf = 1/(1+exp(-(V-V_N1)/k_N1));
        end
        
        function ih_N_inf = h_N_inf(V)
            ih_N_inf = 1/(1+exp(-(V-V_N3)/k_N3));
        end
        
        function itau_mN = tau_mN(V)
            itau_mN = a_N + (b_N/cosh((V+V_N2)/k_N2));
        end
        
        function im_BK_inf = m_BK_inf(V)
            im_BK_inf = 1/(1+exp(-(V-V_BK)/k_BK));
        end
        
        function im_SK_inf = m_SK_inf(iCa_i)
            im_SK_inf = iCa_i^n_HC/(iCa_i^n_HC+K_c^n_HC);
        end
        
        function im_H_inf = m_H_inf(V)
            im_H_inf = 1/(1+exp((V-V_H1)/k_H1));
        end
        
        function iT_m_H = T_m_H(V)
            iT_m_H = a_H/cosh((V-V_H2)/k_H2);
        end
        
        function im_Na_inf = m_Na_inf(V)
            im_Na_inf = 1/(1+exp(-(V-V_Na1)/k_Na1));
        end
        
        function ih_Na_inf = h_Na_inf(V)
            ih_Na_inf = 1/(1+exp((V-V_Na3)/k_Na3));
        end
        
        function iT_m_Na = T_m_Na(V)
            iT_m_Na = a_Na + b_Na * exp(-((V-V_Na2)/k_Na2)^2);
        end
        
        function iT_h_Na = T_h_Na(V)
            iT_h_Na = c_Na + d_Na * exp(-((V-V_Na4)/k_Na4)^2);
        end
        
        function iPB = PB(Ca_i)
            iPB = B_tot/(Ca_i+B_tot+K_d);
        end
    end

% Events function to output spike times
    function [value,isterminal,direction] = spikes(t,v)
        % Locate the time voltage increases through -10mV
        value = v(1)+10;     % Detect height = 0
        isterminal = 0;   % Don't stop the integration
        direction = +1;   % positive direction only
    end

end
